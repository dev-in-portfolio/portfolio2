# AgentX Runner (demo)

This is a tiny local CLI that installs `.agentpack.zip` files into `.agentx/` and runs agents with a basic permission + allowlist model.

## Install
```bash
npm install
node agentx.js --help
```

## Allowlist a workspace
```bash
node agentx.js allow /absolute/path/to/workspace
```

## Install a pack
```bash
node agentx.js install /path/to/pack-a.agentpack.zip
```

## List installed agents
```bash
node agentx.js agents
```

## Run an agent
```bash
node agentx.js run audit-agent --root /absolute/path/to/workspace --approve
```

Notes:
- File reads/writes are blocked unless the target path is inside an allowlisted root.
- Agents may require approvals (`approval.required`) for write/exec/sign actions.
- Browser automation requires Playwright installed and is restricted to demo targets by agent code.
