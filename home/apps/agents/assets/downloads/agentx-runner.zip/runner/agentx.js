#!/usr/bin/env node
const fs = require("fs");
const path = require("path");
const AdmZip = require("adm-zip");
const yargs = require("yargs/yargs");
const { hideBin } = require("yargs/helpers");

const { abs, ensureDir, readJson, writeJson, nowIso } = require("./lib/paths");
const { newRunId, createRunFolder, createReceipts } = require("./lib/receipts");
const { makeTools } = require("./lib/tools");

const AGENTX_HOME = path.join(process.cwd(), ".agentx");
const REGISTRY = path.join(AGENTX_HOME, "registry.json");
const ALLOW = path.join(AGENTX_HOME, "allowlist.json");

function loadAllowlist(){
  const a = readJson(ALLOW, { roots: [] });
  return Array.isArray(a.roots) ? a.roots : [];
}

function addAllowRoot(p){
  const roots = loadAllowlist();
  const ap = abs(p);
  if(!roots.includes(ap)) roots.push(ap);
  writeJson(ALLOW, { roots, updatedAt: nowIso() });
  return roots;
}

function loadRegistry(){ return readJson(REGISTRY, { packs: {} }); }
function saveRegistry(r){ writeJson(REGISTRY, r); }

function installPack(zipPath){
  ensureDir(AGENTX_HOME);
  const z = new AdmZip(zipPath);
  const entry = z.getEntry("pack.json");
  if(!entry) throw new Error("pack.json missing in zip");
  const manifest = JSON.parse(entry.getData().toString("utf-8"));
  if(manifest.format !== "agentpack.v1") throw new Error("Unsupported pack format");
  const dest = path.join(AGENTX_HOME, "packs", manifest.slug);
  // wipe + extract fresh (demo simplicity)
  if(fs.existsSync(dest)) fs.rmSync(dest, { recursive:true, force:true });
  ensureDir(dest);
  z.extractAllTo(dest, true);
  const reg = loadRegistry();
  reg.packs[manifest.slug] = { slug: manifest.slug, name: manifest.name, version: manifest.version, installedAt: nowIso() };
  saveRegistry(reg);
  return manifest;
}

function listAgents(){
  const reg = loadRegistry();
  const packs = Object.keys(reg.packs || {});
  const out = [];
  for(const slug of packs){
    const packRoot = path.join(AGENTX_HOME, "packs", slug);
    const manifest = readJson(path.join(packRoot, "pack.json"), null);
    if(!manifest) continue;
    for(const a of manifest.agents || []){
      out.push({ pack: slug, ...a });
    }
  }
  return out;
}

async function runAgent(agentSlug, argv){
  const agents = listAgents();
  const agent = agents.find(a => a.slug === agentSlug);
  if(!agent) throw new Error(`Agent not found: ${agentSlug}`);
  const packRoot = path.join(AGENTX_HOME, "packs", agent.pack || agent.packSlug || argv.pack || "");
  // In our pack.json we don't store pack field per agent; infer from registry: the agent list includes pack not stored.
  // We'll compute packRoot by scanning manifests.
  let resolvedPackRoot = null;
  for(const p of Object.keys(loadRegistry().packs || {})){
    const m = readJson(path.join(AGENTX_HOME, "packs", p, "pack.json"), null);
    if(!m) continue;
    const hit = (m.agents||[]).find(x=>x.slug===agentSlug);
    if(hit){ resolvedPackRoot = path.join(AGENTX_HOME,"packs",p); break; }
  }
  if(!resolvedPackRoot) throw new Error("Could not resolve pack root for agent");
  const manifest = readJson(path.join(resolvedPackRoot, "pack.json"), null);
  const packSlug = manifest.slug;

  const mainPath = path.join(resolvedPackRoot, agent.main);
  if(!fs.existsSync(mainPath)) throw new Error(`Agent main missing: ${mainPath}`);

  const allowRoots = loadAllowlist();
  if(argv.root){
    const r = abs(argv.root);
    if(!allowRoots.includes(r)){
      throw new Error(`--root is not in allowlist. Run: node agentx.js allow ${r}`);
    }
  }

  const runId = newRunId();
  const runRoot = createRunFolder(AGENTX_HOME, runId);
  const receipts = createReceipts(runRoot, agentSlug, packSlug);

  receipts.addStep("agent.start", { agent: agentSlug, pack: packSlug });
  receipts.log("info", "run.started", { agent: agentSlug, pack: packSlug });

  // Permission gate
  const needsApproval = (agent.permissions || []).some(p => p.startsWith("approval"));
  const approvals = argv.approve === true;

  if(needsApproval && !approvals){
    receipts.log("error", "approval.required", { permissions: agent.permissions });
    receipts.receipts.finishedAt = nowIso();
    receipts.save();
    throw new Error("This agent requires approval. Re-run with --approve");
  }

  const tools = makeTools({ allowRoots, approvals, runRoot, receipts });

  const ctx = {
    inputs: argv,
    argv,
    run: { id: runId, root: runRoot, dir: runRoot },
    tools,
    receipts,
    emit: (event, data={}) => receipts.addStep(event, data),
  };

  let mod;
  try { mod = require(mainPath); }
  catch(e){
    receipts.log("error", "agent.load_failed", { error: e.message });
    throw e;
  }

  if(typeof mod.run !== "function"){
    throw new Error("Agent module must export run(ctx)");
  }

  try{
    await mod.run(ctx);
    receipts.addStep("agent.finish", { ok: true });
    receipts.log("info", "run.finished", { ok: true });
  }catch(e){
    receipts.addStep("agent.finish", { ok: false, error: e.message });
    receipts.log("error", "run.failed", { error: e.message });
    throw e;
  }finally{
    receipts.receipts.finishedAt = nowIso();
    receipts.save();
  }

  return { runId, runRoot };
}

yargs(hideBin(process.argv))
  .scriptName("agentx")
  .command("allow <path>", "Add an allowlisted root", y => y.positional("path",{type:"string"}), (argv)=>{
    const roots = addAllowRoot(argv.path);
    console.log("Allowlist roots:");
    for(const r of roots) console.log(" -", r);
  })
  .command("install <zip>", "Install a .agentpack.zip", y=>y.positional("zip",{type:"string"}), (argv)=>{
    const m = installPack(argv.zip);
    console.log(`Installed ${m.slug} (${m.version}) with ${m.agents.length} agents.`);
  })
  .command("agents", "List installed agents", ()=>{}, ()=>{
    const list = listAgents();
    if(!list.length){ console.log("No packs installed."); return; }
    for(const a of list){
      console.log(`${a.slug}  |  ${a.name}  |  main=${a.main}`);
    }
  })
  .command("run <agentSlug>", "Run an installed agent", y => y
      .positional("agentSlug",{type:"string"})
      .option("root",{type:"string", describe:"workspace root (must be allowlisted)"})
      .option("approve",{type:"boolean", default:false, describe:"approve sensitive actions (writes/exec/sign)"})
      , async (argv)=>{
        try{
          const res = await runAgent(argv.agentSlug, argv);
          console.log("Run complete:", res.runId);
          console.log("Receipts:", path.join(res.runRoot, "receipts.json"));
        }catch(e){
          console.error("Run failed:", e.message);
          process.exitCode = 1;
        }
      })
  .demandCommand(1)
  .help()
  .parse();
